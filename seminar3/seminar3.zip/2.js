//выведение сообщения в console
let userName = prompt("Введите Ваше имя ");
function greeting(userName) {
    console.log(`Привет, ${userName}`);
}
greeting(userName);